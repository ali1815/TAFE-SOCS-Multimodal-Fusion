// ERA5-Land 2018 feature extraction for LUCAS points.
// Google Earth Engine JavaScript.
// This script uses the hourly ERA5-Land collection and constructs annual
// summaries matching the variables used in the manuscript.
// Update ASSET before running.

var ASSET = 'projects/draliresearch/assets/LUCAS_6059_points_COMPLETE_for_GEE';
var points = ee.FeatureCollection(ASSET);
var startDate = '2018-01-01';
var endDate = '2019-01-01';
var europe = ee.Geometry.Rectangle([-35, 25, 45, 72], null, false);

var era = ee.ImageCollection('ECMWF/ERA5_LAND/HOURLY')
  .filterBounds(europe)
  .filterDate(startDate, endDate);

var t2mMean = era.select('temperature_2m').mean().subtract(273.15)
  .rename('CLIM_temperature_mean_C');
var t2mMin = era.select('temperature_2m').min().subtract(273.15)
  .rename('CLIM_temperature_min_C');
var t2mMax = era.select('temperature_2m').max().subtract(273.15)
  .rename('CLIM_temperature_max_C');

var precip = era.select('total_precipitation').sum().multiply(1000)
  .rename('CLIM_precipitation_annual_mm');

var sm1 = era.select('volumetric_soil_water_layer_1').mean()
  .rename('CLIM_soil_moisture_L1_mean_m3m3');
var sm2 = era.select('volumetric_soil_water_layer_2').mean()
  .rename('CLIM_soil_moisture_L2_mean_m3m3');

var st1 = era.select('soil_temperature_level_1').mean().subtract(273.15)
  .rename('CLIM_soil_temperature_L1_mean_C');
var st2 = era.select('soil_temperature_level_2').mean().subtract(273.15)
  .rename('CLIM_soil_temperature_L2_mean_C');

var evap = era.select('total_evaporation').sum().multiply(1000)
  .rename('CLIM_evaporation_annual_mm');

var solar = era.select('surface_solar_radiation_downwards').sum()
  .divide(1e6).rename('CLIM_solar_radiation_annual_MJm2');

var wind = era.map(function(img) {
  var u = img.select('u_component_of_wind_10m');
  var v = img.select('v_component_of_wind_10m');
  return u.pow(2).add(v.pow(2)).sqrt().rename('wind');
}).mean().rename('CLIM_wind_speed_10m_mean_ms');

var out = ee.Image.cat([
  t2mMean, t2mMin, t2mMax, precip,
  sm1, sm2, st1, st2, evap, solar, wind
]);

var sampled = out.sampleRegions({
  collection: points,
  properties: ['POINT_ID'],
  scale: 11132,
  geometries: false
});

Export.table.toDrive({
  collection: sampled,
  description: 'LUCAS_Climate_2018',
  fileFormat: 'CSV'
});
