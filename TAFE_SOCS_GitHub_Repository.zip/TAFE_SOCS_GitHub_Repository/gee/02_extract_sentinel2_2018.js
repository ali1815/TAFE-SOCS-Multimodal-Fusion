// Sentinel-2 2018 feature extraction for LUCAS points.
// Google Earth Engine JavaScript.
// Update ASSET before running.

var ASSET = 'projects/draliresearch/assets/LUCAS_6059_points_COMPLETE_for_GEE';
var points = ee.FeatureCollection(ASSET);
var startDate = '2018-01-01';
var endDate = '2019-01-01';
var europe = ee.Geometry.Rectangle([-35, 25, 45, 72], null, false);

function maskS2(img) {
  var scl = img.select('SCL');
  var mask = scl.neq(0)
    .and(scl.neq(1))
    .and(scl.neq(3))
    .and(scl.neq(7))
    .and(scl.neq(8))
    .and(scl.neq(9))
    .and(scl.neq(10))
    .and(scl.neq(11));
  return img.updateMask(mask);
}

function addIndices(img) {
  var b2 = img.select('B2');
  var b3 = img.select('B3');
  var b4 = img.select('B4');
  var b5 = img.select('B5');
  var b6 = img.select('B6');
  var b7 = img.select('B7');
  var b8 = img.select('B8');
  var b8a = img.select('B8A');
  var b11 = img.select('B11');
  var b12 = img.select('B12');

  var ndvi = img.normalizedDifference(['B8', 'B4']).rename('NDVI');
  var evi = img.expression(
    '2.5*((N-R)/(N+6*R-7.5*B+1))',
    {N:b8, R:b4, B:b2}
  ).rename('EVI');
  var savi = img.expression(
    '1.5*((N-R)/(N+R+0.5))',
    {N:b8, R:b4}
  ).rename('SAVI');
  var msavi = img.expression(
    '(2*N+1-sqrt((2*N+1)*(2*N+1)-8*(N-R)))/2',
    {N:b8, R:b4}
  ).rename('MSAVI');
  var bsi = img.expression(
    '((SW1+R)-(N+B))/((SW1+R)+(N+B))',
    {SW1:b11, R:b4, N:b8, B:b2}
  ).rename('BSI');
  var ndmi = img.normalizedDifference(['B8', 'B11']).rename('NDMI');
  var ndwi = img.normalizedDifference(['B3', 'B8']).rename('NDWI');
  var gndvi = img.normalizedDifference(['B8', 'B3']).rename('GNDVI');
  var ndre1 = img.normalizedDifference(['B8A', 'B5']).rename('NDRE1');
  var ndre2 = img.normalizedDifference(['B8A', 'B6']).rename('NDRE2');
  var ndre3 = img.normalizedDifference(['B8A', 'B7']).rename('NDRE3');
  var nbr = img.normalizedDifference(['B8', 'B12']).rename('NBR');

  return img.addBands([
    ndvi, evi, savi, msavi, bsi, ndmi, ndwi,
    gndvi, ndre1, ndre2, ndre3, nbr
  ]);
}

var s2 = ee.ImageCollection('COPERNICUS/S2_SR_HARMONIZED')
  .filterBounds(europe)
  .filterDate(startDate, endDate)
  .map(maskS2)
  .map(addIndices);

var bands = [
  'B2','B3','B4','B5','B6','B7','B8','B8A','B11','B12',
  'NDVI','EVI','SAVI','MSAVI','BSI','NDMI','NDWI','GNDVI',
  'NDRE1','NDRE2','NDRE3','NBR'
];

var med = s2.select(bands).median();
var renamed = med.rename([
  'S2_B2_median','S2_B3_median','S2_B4_median','S2_B5_median',
  'S2_B6_median','S2_B7_median','S2_B8_median','S2_B8A_median',
  'S2_B11_median','S2_B12_median',
  'S2_NDVI_median','S2_EVI_median','S2_SAVI_median','S2_MSAVI_median',
  'S2_BSI_median','S2_NDMI_median','S2_NDWI_median','S2_GNDVI_median',
  'S2_NDRE1_median','S2_NDRE2_median','S2_NDRE3_median','S2_NBR_median'
]);

var clearCount = s2.select('B4').count().rename('S2_clear_observation_count');
var out = renamed.addBands(clearCount);

var sampled = out.sampleRegions({
  collection: points,
  properties: ['POINT_ID'],
  scale: 20,
  geometries: false
});

Export.table.toDrive({
  collection: sampled,
  description: 'LUCAS_Sentinel2_2018',
  fileFormat: 'CSV'
});
