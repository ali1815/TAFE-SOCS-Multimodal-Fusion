// Sentinel-1 2018 feature extraction for LUCAS points.
// Google Earth Engine JavaScript.
// Update ASSET before running.

var ASSET = 'projects/draliresearch/assets/LUCAS_6059_points_COMPLETE_for_GEE';
var points = ee.FeatureCollection(ASSET);
var startDate = '2018-01-01';
var endDate = '2019-01-01';
var europe = ee.Geometry.Rectangle([-35, 25, 45, 72], null, false);

var s1 = ee.ImageCollection('COPERNICUS/S1_GRD')
  .filterBounds(europe)
  .filterDate(startDate, endDate)
  .filter(ee.Filter.eq('instrumentMode', 'IW'))
  .filter(ee.Filter.eq('resolution_meters', 10))
  .filter(ee.Filter.eq('transmitterReceiverPolarisation', ['VV', 'VH']))
  .select(['VV', 'VH', 'angle']);

var mean = s1.mean();
var median = s1.median();

var sqMean = s1.map(function(img) {
  return img.pow(2);
}).mean();

var variance = sqMean.subtract(mean.pow(2)).max(0);
var std = variance.sqrt();

var vvMean = mean.select('VV');
var vhMean = mean.select('VH');

var vvLinear = ee.Image(10).pow(vvMean.divide(10));
var vhLinear = ee.Image(10).pow(vhMean.divide(10));

var out = ee.Image.cat([
  mean.select('VV').rename('S1_VV_mean_dB'),
  mean.select('VH').rename('S1_VH_mean_dB'),
  mean.select('angle').rename('S1_angle_mean_deg'),
  median.select('VV').rename('S1_VV_median_dB'),
  median.select('VH').rename('S1_VH_median_dB'),
  median.select('angle').rename('S1_angle_median_deg'),
  std.select('VV').rename('S1_VV_std_dB'),
  std.select('VH').rename('S1_VH_std_dB'),
  vvMean.subtract(vhMean).rename('S1_VV_minus_VH_dB'),
  vvLinear.divide(vhLinear).rename('S1_VV_VH_ratio_linear'),
  s1.select('VV').count().rename('S1_observation_count')
]);

var sampled = out.sampleRegions({
  collection: points,
  properties: ['POINT_ID'],
  scale: 10,
  geometries: false
});

Export.table.toDrive({
  collection: sampled,
  description: 'LUCAS_Sentinel1_2018',
  fileFormat: 'CSV'
});
