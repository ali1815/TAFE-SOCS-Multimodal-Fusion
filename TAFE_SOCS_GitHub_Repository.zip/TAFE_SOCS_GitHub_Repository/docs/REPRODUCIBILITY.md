# Reproducibility notes

## Spatial validation

The primary evaluation uses five-fold grouped cross-validation over 100-km blocks in the European equal-area coordinate reference system EPSG:3035.

Country identifiers are not predictive features. They are used only to define leave-country-out tests.

## Leakage control

SOC stock depends on SOC content, fine-earth bulk density, depth, and coarse-fragment volume. Variables directly involved in target construction, including bulk-density and coarse-fragment features, are therefore excluded from the primary prediction feature set.

## Target-quality sensitivity

A separate subset is created using only records whose fine-earth bulk density was directly measured. The final tuned model is re-evaluated on this subset without retuning.

## Conformal uncertainty

Group-aware split conformal prediction uses disjoint spatial blocks for model fitting, calibration, and testing. Nominal 90% and 95% intervals are evaluated using empirical coverage and interval width.

## Random seeds

The main scripts use fixed random seeds (`42` for core modeling; predefined seeds for repeated conformal splits) to improve reproducibility.
