# Results directory

Analysis scripts write tables, predictions, and figures to this directory.

Large generated outputs are excluded from version control by `.gitignore`.
