"""Final spatially tuned XGBoost, SHAP-style contributions, and group-aware conformal uncertainty."""

from pathlib import Path
import math
import numpy as np
import pandas as pd
import xgboost as xgb
from pyproj import Transformer
from sklearn.model_selection import GroupKFold, GroupShuffleSplit
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
from xgboost import XGBRegressor

DATA=Path("data")
RESULTS=Path("results")
RESULTS.mkdir(exist_ok=True)

df=pd.read_csv(DATA/"socs_leakage_safe_model_input.csv")
y=df.SOCS_kg_m2.to_numpy()

s1=[c for c in df if c.startswith("S1_")]
s2=[c for c in df if c.startswith("S2_")]
clim=[c for c in df if c.startswith("CLIM_")]
soil=["Clay","Sand","Silt"]
numeric=s1+s2+clim+soil
land="LC0_Desc"

PARAMS=dict(
    n_estimators=240,max_depth=5,learning_rate=0.03,min_child_weight=5,
    subsample=0.90,colsample_bytree=0.90,reg_lambda=3.0,reg_alpha=0.05,
    objective="reg:squarederror",random_state=42,n_jobs=4
)

def model():
    return XGBRegressor(**PARAMS)

def prep(train,test):
    imp=SimpleImputer(strategy="median")
    a=imp.fit_transform(train[numeric]);b=imp.transform(test[numeric])
    enc=OneHotEncoder(handle_unknown="ignore",sparse_output=False)
    ca=enc.fit_transform(train[[land]]);cb=enc.transform(test[[land]])
    names=numeric+list(enc.get_feature_names_out([land]))
    return np.hstack([a,ca]),np.hstack([b,cb]),names

def met(y,p):
    return dict(R2=r2_score(y,p),
                RMSE=float(np.sqrt(mean_squared_error(y,p))),
                MAE=float(mean_absolute_error(y,p)),
                Bias=float(np.mean(p-y)))

trf=Transformer.from_crs("EPSG:4326","EPSG:3035",always_xy=True)
xx,yy=trf.transform(df.longitude.to_numpy(),df.latitude.to_numpy())
groups=(np.floor(np.asarray(xx)/100000).astype(int).astype(str)+"_"+
        np.floor(np.asarray(yy)/100000).astype(int).astype(str))

# 5-fold spatial CV
oof=np.full(len(df),np.nan)
folds=[]
gkf=GroupKFold(5)
for fold,(tr,te) in enumerate(gkf.split(df,y,groups),1):
    a,b,_=prep(df.iloc[tr],df.iloc[te])
    m=model();m.fit(a,y[tr]);p=np.clip(m.predict(b),0,None)
    oof[te]=p
    folds.append({"Fold":fold,"n_test":len(te),**met(y[te],p)})

pd.DataFrame(folds).to_csv(RESULTS/"final_xgb_spatial_folds.csv",index=False)
pd.DataFrame([met(y,oof)]).to_csv(RESULTS/"final_xgb_spatial_summary.csv",index=False)

# Full-data XGBoost contributions (TreeSHAP-style pred_contribs).
imp=SimpleImputer(strategy="median")
xnum=imp.fit_transform(df[numeric])
enc=OneHotEncoder(handle_unknown="ignore",sparse_output=False)
xcat=enc.fit_transform(df[[land]])
names=numeric+list(enc.get_feature_names_out([land]))
X=np.hstack([xnum,xcat])

m=model();m.fit(X,y)
dm=xgb.DMatrix(X,feature_names=names)
contrib=m.get_booster().predict(dm,pred_contribs=True)
mean_abs=np.mean(np.abs(contrib[:,:-1]),axis=0)

fi=pd.DataFrame({"Feature":names,"MeanAbsSHAP":mean_abs})
def modality(f):
    if f.startswith("S1_"): return "Sentinel-1"
    if f.startswith("S2_"): return "Sentinel-2"
    if f.startswith("CLIM_"): return "Climate"
    if f in soil: return "Soil texture"
    if f.startswith("LC0_Desc_"): return "Land cover"
    return "Other"
fi["Modality"]=fi.Feature.map(modality)
fi.sort_values("MeanAbsSHAP",ascending=False).to_csv(RESULTS/"shap_feature_importance.csv",index=False)
mod=fi.groupby("Modality",as_index=False).MeanAbsSHAP.sum()
mod["Share_pct"]=100*mod.MeanAbsSHAP/mod.MeanAbsSHAP.sum()
mod.to_csv(RESULTS/"shap_modality_contribution.csv",index=False)

# Group-aware conformal with disjoint spatial blocks.
def qhat(scores, alpha):
    n=len(scores)
    q=min(1.0, math.ceil((n+1)*(1-alpha))/n)
    return float(np.quantile(scores,q,method="higher"))

rows=[]
for rep,seed in enumerate([11,22,33,44,55],1):
    idx=np.arange(len(df))
    g1=GroupShuffleSplit(1,test_size=.20,random_state=seed)
    rem,test_idx=next(g1.split(idx,y,groups))
    g2=GroupShuffleSplit(1,test_size=.25,random_state=seed+100)
    tr_rel,cal_rel=next(g2.split(rem,y[rem],groups[rem]))
    tr_idx=rem[tr_rel];cal_idx=rem[cal_rel]

    train,cal,test=df.iloc[tr_idx],df.iloc[cal_idx],df.iloc[test_idx]
    imp=SimpleImputer(strategy="median")
    xtrn=imp.fit_transform(train[numeric]);xcaln=imp.transform(cal[numeric]);xten=imp.transform(test[numeric])
    enc=OneHotEncoder(handle_unknown="ignore",sparse_output=False)
    xtrc=enc.fit_transform(train[[land]]);xcalc=enc.transform(cal[[land]]);xtec=enc.transform(test[[land]])
    xtr=np.hstack([xtrn,xtrc]);xcal=np.hstack([xcaln,xcalc]);xte=np.hstack([xten,xtec])

    mm=model();mm.fit(xtr,y[tr_idx])
    pcal=np.clip(mm.predict(xcal),0,None);pte=np.clip(mm.predict(xte),0,None)
    scores=np.abs(y[cal_idx]-pcal)

    for nominal,alpha in [(0.90,.10),(0.95,.05)]:
        q=qhat(scores,alpha)
        lo=np.maximum(0,pte-q);hi=pte+q
        cov=np.mean((y[test_idx]>=lo)&(y[test_idx]<=hi))
        rows.append({
            "Repeat":rep,"Nominal_Coverage":nominal,
            "R2":r2_score(y[test_idx],pte),
            "RMSE":float(np.sqrt(mean_squared_error(y[test_idx],pte))),
            "MAE":float(mean_absolute_error(y[test_idx],pte)),
            "Conformal_q":q,
            "Empirical_Coverage":float(cov),
            "Mean_Interval_Width":float(np.mean(hi-lo))
        })

pd.DataFrame(rows).to_csv(RESULTS/"conformal_repeated_spatial_splits.csv",index=False)
