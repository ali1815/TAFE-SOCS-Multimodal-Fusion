"""Merge the public SOC-stock target with the prepared sensing dataset and enforce leakage rules."""

from pathlib import Path
import numpy as np
import pandas as pd

DATA = Path("data")
SENSING = DATA / "merged_sensing_2018_model_ready.csv"
SOCS = DATA / "LUCAS SOIL 2018 BD SOCS T-PTF4.csv"

OUT_MASTER = DATA / "socs_master_matched.csv"
OUT_MODEL = DATA / "socs_leakage_safe_model_input.csv"
OUT_HC = DATA / "socs_high_confidence_measured_bd.csv"

df = pd.read_csv(SENSING)
t = pd.read_csv(SOCS)

def norm_id(x):
    return pd.to_numeric(x, errors="coerce").astype("Int64").astype(str)

df["POINT_ID"] = norm_id(df["POINT_ID"])
t["POINTID"] = norm_id(t["POINTID"])

# Normalize source-column naming.
target_map = {
    "SOCS (kg cm-2)": "SOCS_kg_m2",
    "Bdfine (g cm-3)": "TARGET_BDfine_g_cm3",
    "coarse_vol": "TARGET_coarse_vol",
    "BDfine  method ": "TARGET_BDfine_method",
}
keep = ["POINTID"] + [c for c in target_map if c in t.columns]
t = t[keep].rename(columns=target_map)

m = df.merge(t, left_on="POINT_ID", right_on="POINTID", how="inner", validate="one_to_one")
m.drop(columns=["POINTID"], inplace=True)

# Audit-only reconstruction of SOC content; never use it as a predictor.
if {"SOCS_kg_m2", "TARGET_BDfine_g_cm3", "TARGET_coarse_vol"}.issubset(m.columns):
    denom = m["TARGET_BDfine_g_cm3"] * 20.0 * (1.0 - m["TARGET_coarse_vol"])
    m["SOC_content_reconstructed_g_kg_AUDIT_ONLY"] = np.where(
        denom > 0, 100.0 * m["SOCS_kg_m2"] / denom, np.nan
    )

m.to_csv(OUT_MASTER, index=False)

leakage_excluded = {
    "BDsample_0", "BDfine_0_2", "coarse_mas", "coarse_vol",
    "Coarse_texture", "PSDAvailable", "USDA_texture", "ISSS_texture",
    "TARGET_BDfine_g_cm3", "TARGET_coarse_vol",
    "SOC_content_reconstructed_g_kg_AUDIT_ONLY"
}

metadata = ["POINT_ID", "longitude", "latitude", "NUTS_0", "LC0_Desc"]
soil = [c for c in ["Clay", "Sand", "Silt"] if c in m.columns]
sensor = [c for c in m.columns if c.startswith(("S1_", "S2_", "CLIM_"))]

model_cols = metadata + soil + sensor + ["TARGET_BDfine_method", "SOCS_kg_m2"]
model = m[[c for c in model_cols if c in m.columns]].copy()
model.to_csv(OUT_MODEL, index=False)

hc = model[model["TARGET_BDfine_method"].astype(str).str.strip() == "Measurement"].copy()
hc.to_csv(OUT_HC, index=False)

print(f"Matched SOCS rows: {len(model)}")
print(f"High-confidence measured-BD rows: {len(hc)}")
print("Primary leakage-risk variables excluded:", sorted(leakage_excluded))
