"""Final tuned-XGBoost validation on the measured-bulk-density high-confidence subset."""

from pathlib import Path
import numpy as np
import pandas as pd
from pyproj import Transformer
from sklearn.model_selection import GroupKFold
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
from xgboost import XGBRegressor

DATA=Path("data")
RESULTS=Path("results")
RESULTS.mkdir(exist_ok=True)

df=pd.read_csv(DATA/"socs_high_confidence_measured_bd.csv")
y=df.SOCS_kg_m2.to_numpy()

s1=[c for c in df if c.startswith("S1_")]
s2=[c for c in df if c.startswith("S2_")]
clim=[c for c in df if c.startswith("CLIM_")]
numeric=s1+s2+clim+["Clay","Sand","Silt"]
land="LC0_Desc"

def model():
    return XGBRegressor(
        n_estimators=240,max_depth=5,learning_rate=0.03,min_child_weight=5,
        subsample=.90,colsample_bytree=.90,reg_lambda=3.0,reg_alpha=.05,
        objective="reg:squarederror",random_state=42,n_jobs=4
    )

def prep(train,test):
    imp=SimpleImputer(strategy="median")
    a=imp.fit_transform(train[numeric]);b=imp.transform(test[numeric])
    enc=OneHotEncoder(handle_unknown="ignore",sparse_output=False)
    ca=enc.fit_transform(train[[land]]);cb=enc.transform(test[[land]])
    return np.hstack([a,ca]),np.hstack([b,cb])

def met(y,p):
    return dict(R2=r2_score(y,p),
                RMSE=float(np.sqrt(mean_squared_error(y,p))),
                MAE=float(mean_absolute_error(y,p)),
                Bias=float(np.mean(p-y)))

trf=Transformer.from_crs("EPSG:4326","EPSG:3035",always_xy=True)
xx,yy=trf.transform(df.longitude.to_numpy(),df.latitude.to_numpy())
groups=(np.floor(np.asarray(xx)/100000).astype(int).astype(str)+"_"+
        np.floor(np.asarray(yy)/100000).astype(int).astype(str))

oof=np.full(len(df),np.nan)
folds=[]
gkf=GroupKFold(5)
for fold,(tr,te) in enumerate(gkf.split(df,y,groups),1):
    a,b=prep(df.iloc[tr],df.iloc[te])
    m=model();m.fit(a,y[tr]);p=np.clip(m.predict(b),0,None)
    oof[te]=p
    folds.append({"Fold":fold,"n_test":len(te),**met(y[te],p)})

pd.DataFrame(folds).to_csv(RESULTS/"high_confidence_spatial_folds.csv",index=False)
pd.DataFrame([{"n_samples":len(df),**met(y,oof)}]).to_csv(
    RESULTS/"high_confidence_spatial_summary.csv",index=False
)

# LOCO on countries with at least 100 high-confidence samples.
counts=df.NUTS_0.value_counts()
countries=list(counts[counts>=100].index)
rows=[]
for country in countries:
    train=df[df.NUTS_0!=country]
    test=df[df.NUTS_0==country]
    a,b=prep(train,test)
    m=model();m.fit(a,train.SOCS_kg_m2)
    p=np.clip(m.predict(b),0,None)
    rows.append({
        "Held_out_country":country,"n_test":len(test),
        **met(test.SOCS_kg_m2.to_numpy(),p)
    })

pd.DataFrame(rows).to_csv(RESULTS/"high_confidence_loco.csv",index=False)
