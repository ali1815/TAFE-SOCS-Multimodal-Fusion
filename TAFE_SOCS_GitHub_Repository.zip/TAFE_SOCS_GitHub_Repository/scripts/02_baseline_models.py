"""Untuned baseline models under random and 100-km spatial validation."""

from pathlib import Path
import numpy as np
import pandas as pd
from pyproj import Transformer
from sklearn.model_selection import train_test_split, GroupKFold
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
from sklearn.ensemble import RandomForestRegressor
from xgboost import XGBRegressor
from catboost import CatBoostRegressor

DATA = Path("data")
RESULTS = Path("results")
RESULTS.mkdir(exist_ok=True)

df = pd.read_csv(DATA / "socs_leakage_safe_model_input.csv")
y = df["SOCS_kg_m2"].astype(float).to_numpy()
features = [c for c in df.columns if c.startswith(("S1_", "S2_", "CLIM_"))]
X = df[features].astype(float).fillna(df[features].median(numeric_only=True))

trf = Transformer.from_crs("EPSG:4326", "EPSG:3035", always_xy=True)
x, yy = trf.transform(df.longitude.to_numpy(), df.latitude.to_numpy())
groups = (np.floor(np.asarray(x)/100000).astype(int).astype(str) + "_" +
          np.floor(np.asarray(yy)/100000).astype(int).astype(str))

def metrics(yt, yp):
    return dict(
        R2=r2_score(yt, yp),
        RMSE=float(np.sqrt(mean_squared_error(yt, yp))),
        MAE=float(mean_absolute_error(yt, yp)),
    )

def model(name):
    if name == "Random Forest":
        return RandomForestRegressor(
            n_estimators=100, max_features="sqrt", min_samples_leaf=2,
            random_state=42, n_jobs=-1
        )
    if name == "XGBoost":
        return XGBRegressor(
            n_estimators=150, max_depth=6, learning_rate=0.06,
            subsample=0.8, colsample_bytree=0.8,
            objective="reg:squarederror", random_state=42, n_jobs=4
        )
    return CatBoostRegressor(
        iterations=100, depth=6, learning_rate=0.06,
        loss_function="RMSE", random_seed=42, verbose=False, thread_count=4
    )

rows = []
idx = np.arange(len(df))
tr, te = train_test_split(idx, test_size=0.20, random_state=42)

for name in ["Random Forest", "XGBoost", "CatBoost"]:
    for mode in ["raw", "log1p"]:
        m = model(name)
        yt = y if mode == "raw" else np.log1p(y)
        m.fit(X.iloc[tr], yt[tr])
        p = m.predict(X.iloc[te])
        if mode == "log1p":
            p = np.expm1(p)
        p = np.clip(p, 0, None)
        rows.append({"Validation":"Random 80/20","Model":name,"Target":mode,**metrics(y[te],p)})

gkf = GroupKFold(5)
for name in ["Random Forest", "XGBoost", "CatBoost"]:
    for mode in ["raw", "log1p"]:
        obs, pred = [], []
        yt = y if mode == "raw" else np.log1p(y)
        for tr, te in gkf.split(X, y, groups):
            m = model(name)
            m.fit(X.iloc[tr], yt[tr])
            p = m.predict(X.iloc[te])
            if mode == "log1p":
                p = np.expm1(p)
            obs.extend(y[te])
            pred.extend(np.clip(p, 0, None))
        rows.append({
            "Validation":"Spatial 5-fold (100 km)",
            "Model":name,"Target":mode,
            **metrics(np.asarray(obs), np.asarray(pred))
        })

pd.DataFrame(rows).to_csv(RESULTS / "baseline_summary.csv", index=False)
