"""Leave-country-out evaluation and measured-BD target-quality sensitivity."""

from pathlib import Path
import numpy as np
import pandas as pd
from pyproj import Transformer
from sklearn.model_selection import GroupKFold
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error

DATA = Path("data")
RESULTS = Path("results")
RESULTS.mkdir(exist_ok=True)

full = pd.read_csv(DATA / "socs_leakage_safe_model_input.csv")
hc = pd.read_csv(DATA / "socs_high_confidence_measured_bd.csv")

s1 = [c for c in full if c.startswith("S1_")]
s2 = [c for c in full if c.startswith("S2_")]
clim = [c for c in full if c.startswith("CLIM_")]
soil = ["Clay","Sand","Silt"]
land = "LC0_Desc"

configs = {
    "Sensor fusion": s1+s2+clim,
    "Full fusion": s1+s2+clim+soil+[land],
}

def prep(train, test, cols):
    num = [c for c in cols if c != land]
    imp = SimpleImputer(strategy="median")
    a = imp.fit_transform(train[num]); b = imp.transform(test[num])
    if land in cols:
        enc = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        ca = enc.fit_transform(train[[land]]); cb = enc.transform(test[[land]])
        a, b = np.hstack([a,ca]), np.hstack([b,cb])
    return a, b

def rf():
    return RandomForestRegressor(
        n_estimators=60, max_depth=20, max_features="sqrt",
        min_samples_leaf=2, random_state=42, n_jobs=-1
    )

def met(y,p):
    return dict(
        R2=r2_score(y,p),
        RMSE=float(np.sqrt(mean_squared_error(y,p))),
        MAE=float(mean_absolute_error(y,p)),
        Bias=float(np.mean(p-y))
    )

country_counts = full.NUTS_0.value_counts()
countries = list(country_counts[country_counts >= 100].index)
loco = []

for country in countries:
    train = full[full.NUTS_0 != country]
    test = full[full.NUTS_0 == country]
    for name, cols in configs.items():
        a,b = prep(train,test,cols)
        m = rf(); m.fit(a, train.SOCS_kg_m2)
        p = np.clip(m.predict(b),0,None)
        loco.append({"Held_out_country":country,"Configuration":name,"n_test":len(test),**met(test.SOCS_kg_m2.to_numpy(),p)})

pd.DataFrame(loco).to_csv(RESULTS/"leave_country_out.csv",index=False)

# Sensitivity on all matched vs measured-BD subset.
sens = []
for dsname,d in [("All matched",full),("Measured-BD high-confidence",hc)]:
    trf = Transformer.from_crs("EPSG:4326","EPSG:3035",always_xy=True)
    xx,yy = trf.transform(d.longitude.to_numpy(),d.latitude.to_numpy())
    groups = (np.floor(np.asarray(xx)/100000).astype(int).astype(str)+"_"+
              np.floor(np.asarray(yy)/100000).astype(int).astype(str))
    y=d.SOCS_kg_m2.to_numpy()
    gkf=GroupKFold(5)
    for name,cols in configs.items():
        obs,pred=[],[]
        for tr,te in gkf.split(d,y,groups):
            a,b=prep(d.iloc[tr],d.iloc[te],cols)
            m=rf();m.fit(a,y[tr])
            p=np.clip(m.predict(b),0,None)
            obs.extend(y[te]);pred.extend(p)
        sens.append({"Dataset":dsname,"Configuration":name,"n_samples":len(d),**met(np.asarray(obs),np.asarray(pred))})

pd.DataFrame(sens).to_csv(RESULTS/"target_quality_sensitivity.csv",index=False)
