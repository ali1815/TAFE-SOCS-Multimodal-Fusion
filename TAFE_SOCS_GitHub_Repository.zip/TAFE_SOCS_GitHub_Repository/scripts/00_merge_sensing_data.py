"""Merge LUCAS metadata, Sentinel-1, Sentinel-2, and ERA5-Land tables by POINT_ID."""

from pathlib import Path
import pandas as pd

DATA = Path("data")
OUT = DATA / "merged_sensing_2018_with_qc.csv"
MODEL = DATA / "merged_sensing_2018_model_ready.csv"

metadata = pd.read_csv(DATA / "01_LUCAS_Point_Metadata_6059.csv")
s1 = pd.read_csv(DATA / "LUCAS_Sentinel1_2018.csv")
s2 = pd.read_csv(DATA / "LUCAS_Sentinel2_2018.csv")
clim = pd.read_csv(DATA / "LUCAS_Climate_2018.csv")

def norm_id(s):
    return pd.to_numeric(s, errors="coerce").astype("Int64").astype(str)

for d, col in [(metadata, "POINT_ID"), (s1, "POINT_ID"), (s2, "POINT_ID"), (clim, "POINT_ID")]:
    d[col] = norm_id(d[col])

# Drop export-generated geometry/coordinate columns from sensor tables where present.
drop_aux = [".geo", "system:index", "longitude", "latitude"]
for d in (s1, s2, clim):
    d.drop(columns=[c for c in drop_aux if c in d.columns], inplace=True, errors="ignore")

merged = metadata.merge(s1, on="POINT_ID", how="left", validate="one_to_one")
merged = merged.merge(s2, on="POINT_ID", how="left", validate="one_to_one")
merged = merged.merge(clim, on="POINT_ID", how="left", validate="one_to_one")

clim_cols = [c for c in merged.columns if c.startswith("CLIM_")]
merged["CLIMATE_QC"] = merged[clim_cols].notna().all(axis=1).map(
    {True: "VALID", False: "MASKED_ERA5LAND_PIXEL"}
)

merged.to_csv(OUT, index=False)

model = merged[merged["CLIMATE_QC"] == "VALID"].copy()
model.to_csv(MODEL, index=False)

print(f"All merged rows: {len(merged)}")
print(f"Model-ready rows: {len(model)}")
print(f"Climate-masked rows: {(merged.CLIMATE_QC != 'VALID').sum()}")
