"""Fixed-RF multimodal ablation under 100-km spatial cross-validation."""

from pathlib import Path
import numpy as np
import pandas as pd
from pyproj import Transformer
from sklearn.model_selection import GroupKFold
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error

DATA = Path("data")
RESULTS = Path("results")
RESULTS.mkdir(exist_ok=True)

df = pd.read_csv(DATA / "socs_leakage_safe_model_input.csv")
y = df.SOCS_kg_m2.to_numpy()

s1 = [c for c in df if c.startswith("S1_")]
s2 = [c for c in df if c.startswith("S2_")]
clim = [c for c in df if c.startswith("CLIM_")]
soil = ["Clay", "Sand", "Silt"]
land = "LC0_Desc"

configs = {
    "S1 only": s1,
    "S2 only": s2,
    "Climate only": clim,
    "S1 + S2": s1+s2,
    "S1 + S2 + Climate": s1+s2+clim,
    "S1 + S2 + Climate + Soil": s1+s2+clim+soil,
    "Full fusion (+ Land Cover)": s1+s2+clim+soil+[land],
}

trf = Transformer.from_crs("EPSG:4326", "EPSG:3035", always_xy=True)
xx, yy = trf.transform(df.longitude.to_numpy(), df.latitude.to_numpy())
groups = (np.floor(np.asarray(xx)/100000).astype(int).astype(str) + "_" +
          np.floor(np.asarray(yy)/100000).astype(int).astype(str))

def prep(train, test, cols):
    numeric = [c for c in cols if c != land]
    imp = SimpleImputer(strategy="median")
    a = imp.fit_transform(train[numeric])
    b = imp.transform(test[numeric])
    if land in cols:
        enc = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        ca = enc.fit_transform(train[[land]])
        cb = enc.transform(test[[land]])
        a, b = np.hstack([a,ca]), np.hstack([b,cb])
    return a, b

def score(yt, yp):
    return {
        "R2":r2_score(yt,yp),
        "RMSE":float(np.sqrt(mean_squared_error(yt,yp))),
        "MAE":float(mean_absolute_error(yt,yp))
    }

rows = []
gkf = GroupKFold(5)
for name, cols in configs.items():
    obs, pred = [], []
    for tr, te in gkf.split(df, y, groups):
        a, b = prep(df.iloc[tr], df.iloc[te], cols)
        m = RandomForestRegressor(
            n_estimators=60, max_depth=20, max_features="sqrt",
            min_samples_leaf=2, random_state=42, n_jobs=-1
        )
        m.fit(a, y[tr])
        p = np.clip(m.predict(b), 0, None)
        obs.extend(y[te]); pred.extend(p)
    rows.append({"Configuration":name, **score(np.asarray(obs), np.asarray(pred))})

pd.DataFrame(rows).to_csv(RESULTS / "multimodal_ablation.csv", index=False)
