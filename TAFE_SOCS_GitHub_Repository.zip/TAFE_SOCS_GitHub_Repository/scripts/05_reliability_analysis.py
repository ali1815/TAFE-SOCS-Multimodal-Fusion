"""Secondary reliability analysis using S1/S2 observation-count interactions."""

from pathlib import Path
import numpy as np
import pandas as pd
from pyproj import Transformer
from sklearn.model_selection import GroupKFold
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
from xgboost import XGBRegressor

DATA=Path("data")
RESULTS=Path("results")
RESULTS.mkdir(exist_ok=True)

df=pd.read_csv(DATA/"socs_leakage_safe_model_input.csv")
y=df.SOCS_kg_m2.to_numpy()

s1=[c for c in df if c.startswith("S1_")]
s2=[c for c in df if c.startswith("S2_")]
clim=[c for c in df if c.startswith("CLIM_")]
soil=["Clay","Sand","Silt"]
land="LC0_Desc"
base=s1+s2+clim+soil

def rel_scale(train, test):
    q10,q90=np.nanquantile(train,[.1,.9])
    d=max(q90-q10,1e-9)
    return np.clip((train-q10)/d,0,1),np.clip((test-q10)/d,0,1)

def prep(train,test,reliability):
    imp=SimpleImputer(strategy="median")
    a=pd.DataFrame(imp.fit_transform(train[base]),columns=base)
    b=pd.DataFrame(imp.transform(test[base]),columns=base)
    if reliability:
        r1a,r1b=rel_scale(a.S1_observation_count.to_numpy(),b.S1_observation_count.to_numpy())
        r2a,r2b=rel_scale(a.S2_clear_observation_count.to_numpy(),b.S2_clear_observation_count.to_numpy())
        ea={"RA_S1_reliability":r1a,"RA_S2_reliability":r2a,
            "RA_joint_mean_reliability":(r1a+r2a)/2,
            "RA_joint_min_reliability":np.minimum(r1a,r2a),
            "RA_reliability_imbalance":np.abs(r1a-r2a)}
        eb={"RA_S1_reliability":r1b,"RA_S2_reliability":r2b,
            "RA_joint_mean_reliability":(r1b+r2b)/2,
            "RA_joint_min_reliability":np.minimum(r1b,r2b),
            "RA_reliability_imbalance":np.abs(r1b-r2b)}
        for c in s1:
            if c!="S1_observation_count":
                ea["RA_S1x_"+c]=a[c].to_numpy()*r1a
                eb["RA_S1x_"+c]=b[c].to_numpy()*r1b
        for c in s2:
            if c!="S2_clear_observation_count":
                ea["RA_S2x_"+c]=a[c].to_numpy()*r2a
                eb["RA_S2x_"+c]=b[c].to_numpy()*r2b
        a=pd.concat([a,pd.DataFrame(ea)],axis=1)
        b=pd.concat([b,pd.DataFrame(eb)],axis=1)
    enc=OneHotEncoder(handle_unknown="ignore",sparse_output=False)
    ca=enc.fit_transform(train[[land]]);cb=enc.transform(test[[land]])
    return np.hstack([a,ca]),np.hstack([b,cb])

def model():
    return XGBRegressor(
        n_estimators=160,max_depth=5,learning_rate=.04,min_child_weight=4,
        subsample=.85,colsample_bytree=.85,reg_lambda=2.0,
        objective="reg:squarederror",random_state=42,n_jobs=4
    )

def met(y,p):
    return dict(R2=r2_score(y,p),
                RMSE=float(np.sqrt(mean_squared_error(y,p))),
                MAE=float(mean_absolute_error(y,p)))

trf=Transformer.from_crs("EPSG:4326","EPSG:3035",always_xy=True)
xx,yy=trf.transform(df.longitude.to_numpy(),df.latitude.to_numpy())
groups=(np.floor(np.asarray(xx)/100000).astype(int).astype(str)+"_"+
        np.floor(np.asarray(yy)/100000).astype(int).astype(str))

rows=[]
gkf=GroupKFold(5)
for label,ra in [("Standard full fusion",False),("Reliability-aware fusion",True)]:
    obs,pred=[],[]
    for tr,te in gkf.split(df,y,groups):
        a,b=prep(df.iloc[tr].reset_index(drop=True),df.iloc[te].reset_index(drop=True),ra)
        m=model();m.fit(a,y[tr]);p=np.clip(m.predict(b),0,None)
        obs.extend(y[te]);pred.extend(p)
    rows.append({"Variant":label,**met(np.asarray(obs),np.asarray(pred))})

pd.DataFrame(rows).to_csv(RESULTS/"reliability_analysis.csv",index=False)
