# Data required for reproduction

This repository intentionally does not redistribute source datasets.

Expected local files may include:

- `01_LUCAS_Point_Metadata_6059.csv`
- `LUCAS_Sentinel1_2018.csv`
- `LUCAS_Sentinel2_2018.csv`
- `LUCAS_Climate_2018.csv`
- `LUCAS SOIL 2018 BD SOCS T-PTF4.csv`

The pipeline produces:

- a merged sensing dataset
- a leakage-safe SOCS modeling dataset
- a measured-bulk-density high-confidence subset

## Original sources

### LUCAS 2018 topsoil
European Soil Data Centre / European Commission Joint Research Centre.

### SOC stock target
Chen et al. (2024), *Earth System Science Data*, European topsoil bulk density and organic carbon stock database (0–20 cm).

### Sentinel-1 and Sentinel-2
Copernicus / ESA collections accessed through Google Earth Engine.

### ERA5-Land
ECMWF ERA5-Land collections accessed through Google Earth Engine.

Users are responsible for complying with the original data-provider access, licensing, and redistribution terms.
